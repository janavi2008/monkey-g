var bananaImage, obstacleImage, obstaclegroup, backGround, score, monkey, banana;

function preoad() {
  backGround = loadImage("jungle.png");

  player_running = loadImage("Monkey_01.png", "Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", "Monkey_07.png", "Monkey_08.png", "Monkey_09.png", "Monkey_10.png");

  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("stone.png");
}

function setup() {
  createCanvas(400, 400);


  backGround = createSprite(200, 200, 20, 50);
  backGround.addAnimation("jungle.jpg");
  backGround.x = backGround.width / 2;
  backGround.velocityX = -2;

  monkey = createSprite(200, 200, 20, 50);
  monkey.addAnimation("Monkey_01.png", "Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", "Monkey_07.png", "Monkey_08.png", "Monkey_09.png", "Monkey_10.png", player_running);

  bananaGroup = new Group();
  obstacleGroup = new Group();

}

function draw() {
  background(220);

  if (bananaGroup.isTouching(monkey)) {

    score = score + 2;
    bananaGroup.destroyEach();
    switch (score) {
      case 10:
        monkey.scale = 0.12;
        break;
      case 20:
        monkey.scale = 0.14;
        break;
      case 30:
        monkey.scale = 0.16;
        break;
      case 40:
        monkey.scale = 0.18;
        break;
    }

  }
     if (obstacleGroup.isTouching(monkey)) {
    obstacleGroup.destroyEach();
       monkey.scale = 0.2
       
     }

  spawnObstacles() ;
  spawnbanana();

  drawSprites();
}

function spawnbanana() {
  if (frameCount % 60 === 0) {
    var banana = createSprite(600, 120, 40, 10);
    banana.y = Math.round(random(80, 120));
    banana.addImage("cloud", cloudImage);
    banana.scale = 0.5;
    banana.velocityX = -3;
    banana.lifetime = 200;
    cloudGroup.add(cloud)}   
  
  
}
  
  function spawnObstacles() {
  if (frameCount % 60 === 0) {
    var obstacle = createSprite(600, 165, 10, 40);
    obstacle.velocityX = -6;
    obstacle.scale = 0.5;
    obstacle.lifetime = 100;
    obstacleGroup.add(obstacle);
  }
}
